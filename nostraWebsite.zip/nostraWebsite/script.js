let closenav = document.getElementById('close')
let banner = document.getElementById('banner')
closenav.addEventListener('click',function(){
    banner.style.display='none'
})

let imgbox=document.getElementById('imgbox')
let previousbtn=document.getElementById('previousbtn')
let nextbtn=document.getElementById('nextbtn')

nextbtn.addEventListener('click',function(){
    imgbox.style.scrollBehavior = 'smooth'
    imgbox.scrollLeft +=1535
    // imgbox.scrollLeft -=1535
})
previousbtn.addEventListener('click',function(){
    imgbox.style.scrollBehavior = 'smooth'
    imgbox.scrollLeft -=1535
})