// Product Search Functionality

let productContainer = document.getElementById('product-container')
let search = document.getElementById('search')
let productlist = productContainer.querySelectorAll('div')
let checkbox = 


search.addEventListener('keyup',function(){
    let enteredValue=this.value.toUpperCase()
    for(count=0;count<productlist.length;count=count+1)
    {
        let productname =  productlist[count].querySelector('h2').textContent

        if(productname.toUpperCase().indexOf(enteredValue)<0)
        {
            productlist[count].style.display='none'
        }
        else{
            productlist[count].style.display='block'
        }
    }
})

document.addEventListener('DOMContentLoaded', function () {
    let checkboxes = document.querySelectorAll('input[type="checkbox"]');

    checkboxes.forEach(function (checkbox) {
        checkbox.addEventListener('change', function () {
            let selectedValues = Array.from(checkboxes)
                .filter(cb => cb.checked)
                .map(cb => cb.value.toLowerCase());

            productContainer.querySelectorAll('.first').forEach(function (product) {
                let productName = product.querySelector('h2').textContent.toLowerCase();
                let productMatches = selectedValues.some(value => productName.includes(value));
                if (selectedValues.length === 0 || productMatches) {
                    product.style.display = 'block';
                } else {
                    product.style.display = 'none';
                }
            });
        });
    });
});

